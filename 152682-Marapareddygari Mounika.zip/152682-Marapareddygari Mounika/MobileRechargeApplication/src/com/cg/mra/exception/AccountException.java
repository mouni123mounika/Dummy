package com.cg.mra.exception;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	Exception
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
public class AccountException extends Exception {
	
	private static final long serialVersionUID = 3765924119883535214L;
	public AccountException() {
		super();
	}
	public AccountException(String msg) {
		super(msg);
	}

}
