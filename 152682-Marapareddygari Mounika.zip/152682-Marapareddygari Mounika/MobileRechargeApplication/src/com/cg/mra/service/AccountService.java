package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	AccountService
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
public interface AccountService {

	Account getAccountDetails(String mobileNo);

	Account rechargeAccount(String mobileNo, String rechargeAmount) throws AccountException;
	public boolean validatemobileNo(String mobileNo) throws AccountException;
	boolean validateMoney(String accountBalance) throws AccountException;
	

}
