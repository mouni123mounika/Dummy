package com.cg.mra.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	To test rechargeAccount using JUnit
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/10/2018
	 ********************************************************************************************************/

public class AccountJunitTest {

	private static AccountService rechargeAccount = null;

	@BeforeClass
	public static void setUpBeforeClass() throws AccountException {
		rechargeAccount = new AccountServiceImpl();
	}

	@Test
	public void testmobilenumberWhenInput() {
		Account account = rechargeAccount.getAccountDetails("9874563210");
		assertNotNull(account);
		System.out.println("Hi...Mouni");
	}

	@Test
	public void testmobilenumberWhenInputWrong() {
		Account account = rechargeAccount.getAccountDetails("mouni");
		assertNull(account);
		System.out.println("Testing Ended");
	}

	@Test
	public void testmobilenumberWhenNoInput() {
		Account account = rechargeAccount.getAccountDetails("");
		assertNull(account);
	}
	
	@Test(expected = AccountException.class)
	public void testrechargeAmountWhenNoInputs() throws AccountException {
		Account account = rechargeAccount.rechargeAccount("", "");
		assertNull(account);
	}
	@Test(expected = AccountException.class)
	public void testrechargeAmountWhenSpaceInputs() throws AccountException {
		Account account = rechargeAccount.rechargeAccount("", "200");
		assertNull(account);
	}

	@Test(expected = AccountException.class)
	public void testrechargeAmountWhenNoInput() throws AccountException {
		Account account = rechargeAccount.rechargeAccount("123", "");
		assertNull(account);
		
	}

}
