package com.cg.mra.service;

import com.cg.mra.beans.Account;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	AcoountService
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	AccountService
	 - Input Parameters	:	String MobileNo
	 - Return Type		:	Boolean
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
public class AccountServiceImpl implements AccountService {

	AccountDao dao = new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) {
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public Account rechargeAccount(String mobileNo, String rechargeAmount) throws AccountException {
		Account account = dao.rechargeAccount(mobileNo, rechargeAmount);
		if (account == null) {
			throw new AccountException("Mobile Number not found");
		}
		return account;
	}

	@Override
		public boolean validatemobileNo(String mobileNo) throws AccountException {
			if (!(mobileNo.matches("[7-9]{1}[0-9]{9}+"))) {
				throw new AccountException("Enter correct Mobile Number");
			}
			return true;
		}

	@Override
	public boolean validateMoney(String accountBalance) throws AccountException {
		if (!(accountBalance.matches("\\d+"))) {
			throw new AccountException("please enter correct amount to add");
		}
		return true;
	}

}
