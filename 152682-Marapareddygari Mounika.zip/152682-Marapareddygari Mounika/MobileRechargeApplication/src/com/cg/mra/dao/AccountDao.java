package com.cg.mra.dao;

import com.cg.mra.beans.Account;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	AccountDaoInterface
	 - Input Parameters	:	String Mobile Number
	 - Input Parameters	:	String MobileNo
	 - Return Type		:	Boolean
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
public interface AccountDao {

	Account getAccountDetails(String mobileNo);

	Account rechargeAccount(String mobileNo, String rechargeAmount);

}
