package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	AccountDao
	 - Input Parameters	:	HashMap<String,Account>
	 - Return Type		:	Account
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
public class AccountDaoImpl implements AccountDao {
	
private static HashMap<String,Account> customer=null;
	
	static{
		customer=new HashMap<>();
		
		Account account1=new Account();
		account1.setMobileNo("9994521881");
		account1.setAccountType("Airtel");
		account1.setCustomerName("Mouni");
		account1.setAccountBalance("100.00");
		
		Account account2=new Account();
		account2.setMobileNo("9876543210");
		account2.setAccountType("BSNL");
		account2.setCustomerName("Mounika");
		account2.setAccountBalance("200.00");
		
		Account account3=new Account();
		account3.setMobileNo("9874563210");
		account3.setAccountType("BSNL");
		account3.setCustomerName("Mounika");
		account3.setAccountBalance("300.00");
		
		customer.put(account1.getMobileNo(),account1);
		customer.put(account2.getMobileNo(),account2);
		customer.put(account3.getMobileNo(),account3);
	}

	@Override
	public Account getAccountDetails(String mobileNo) {
		Account account=customer.get(mobileNo);
		if(account!=null)
		{
			return account;
		}
		return null;
	}

	@Override
	public Account rechargeAccount(String mobileNo, String rechargeAmount) {
		Account account=customer.get(mobileNo);
		if(account!=null)
		{
			double updateBal=Double.parseDouble(account.getAccountBalance())+Double.parseDouble(rechargeAmount);
			String balance=String.valueOf(updateBal);
			account.setAccountBalance(balance);;
			return account;
		}
		return null;
	}

}
