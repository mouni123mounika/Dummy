package com.cg.mra.beans;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	AccountDetails
	 - Input Parameters	:	String 
	 - Return Type		:	Account
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/

public class Account {
	private String mobileNo;
	private String accountType;
	private String customerName;
	private String accountBalance;
	private int rechargeAccount;

	public Account() {
	}

	public Account(String mobileNo, String accountType, String customerName, String accountBalance) {
		super();
		this.mobileNo = mobileNo;
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getRechargeAccount() {
		return rechargeAccount;
	}

	public void setRechargeAccount(int rechargeAccount) {
		this.rechargeAccount = rechargeAccount;
	}
	

}
