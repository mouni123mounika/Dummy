package com.cg.mra.ui;

import java.util.Scanner;
import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
//------------------------    MobileRechargeApplication --------------------------
	/*******************************************************************************************************
	 - Method Name	:	To view and check Customer Details
	 - Input Parameters	:	AccountServieImpl,AccountDao
	 - Throws			:  	AccountException
	 - Author			:	Marapareddygari Mounika
	 - Creation Date	:	11/10/2018
	 ********************************************************************************************************/

public class MainUI {

	public static void main(String[] args) {

		AccountService service = new AccountServiceImpl();

		int choice = 0;

		boolean error = false;
		String money;
		String ch;
		do {
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3.Exit");
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter the Choice:");
			choice = scanner.nextInt();
			switch (choice) {
			
			case 1:

				System.out.println("Enter customer mobileNo:");
				String mobileNo = scanner.next();
				try {
					error = service.validatemobileNo(mobileNo);
				} catch (AccountException e) {
					System.out.println(e.getMessage());
				}

				if (error) {
					Account details = service.getAccountDetails(mobileNo);
					if (details != null) {
						System.out.println("MobileNumber of customer is: " + details.getMobileNo());
						System.out.println("Name of customer is: " + details.getCustomerName());
						System.out.println("Account Balance: " + details.getAccountBalance());
					} else {
						System.out.println("ERROR: Given Mobile Number Does Not Exits");
					}

				}
				break;
			case 2:
				System.out.println("Enter customer Mobile Number :");
				String mobileNo1 = scanner.next();
				try {
					error = service.validatemobileNo(mobileNo1);

					if (error) {
						System.out.println("Enter the recharge amount:");
						money = scanner.next();

						error = service.validateMoney(money);

						if (error) {

							Account details1 = service.rechargeAccount(mobileNo1, money);

							System.out.println("MobileNumber of customer is: " + details1.getMobileNo());
							System.out.println("Name of customer is: " + details1.getCustomerName());
							System.out.println("Account Balance: " + details1.getAccountBalance());

						}
					} else {
						System.out.println("Cannot recharge Account as Given Mobile no Does Not Exits ......");
					}

				} catch (AccountException e) {
					System.out.println(e.getMessage());
				}

				break;

			case 3:
				System.out.println("Thank you for using");
				System.exit(0);
				break;
			default:
				System.out.println("enter correct Mobile Number");

			}
			System.out.println("Enter y or yes to continue and n or no to Exit");
			ch = scanner.next();
		} while ((ch.equalsIgnoreCase("y")) || ch.equalsIgnoreCase("yes"));
	}

}
